<template>
  <div>
    <!-- 控制台 -->
  </div>
</template>

<script setup>
import { getcityconfiguration } from "@/api";
const route = useRoute();
</script>

<style lang="scss" scoped>
</style>